#pragma once

#include "triangulation.h" // <--- Incluye la nueva CLASE Triangulation
#include <iostream>
#include <vector>
#include <cmath>
#include <numeric> 
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <omp.h>
#include <algorithm> 

// Here starts the "gpu" code!!!!!!!

typedef int bit_vector_d;

// NOTA: Las funciones 'inline' 'twin_d', 'next_d', 'prev_d', 'origin_d', etc.,
// han sido eliminadas. Ahora usaremos los métodos de la clase Triangulation,
// como tr.twin(e), tr.next(e), etc.

// Las funciones 'kernel' ahora toman una referencia a la clase Triangulation
// para poder llamar a sus métodos.

// --- Implementación de funciones auxiliares que SÍ estaban en kernel.cu ---

inline int Equality(double a, double b, double epsilon) {
  return fabs(a - b) < epsilon;
}
 
inline int GreaterEqualthan(double a, double b, double epsilon){
    return Equality(a,b,epsilon) || a > b;
}

// Calcula el borde más largo de un triángulo (cara)
// 'e' es *cualquier* half-edge de esa cara.
inline int compute_max_edge_d(Triangulation &tr, int e){
    double epsion = 0.0000000001f;
    // Llama al método distance() de la clase Triangulation
    double l0 = tr.distance(e); 
    double l1 = tr.distance(tr.next(e)); 
    double l2 = tr.distance(tr.prev(e)); 

   if( (GreaterEqualthan(l0,l1,epsion) && GreaterEqualthan(l1,l2,epsion)) || ( GreaterEqualthan(l0,l2,epsion) && GreaterEqualthan(l2,l1,epsion)))
   {
           return e;
   }
   else if((GreaterEqualthan(l1,l0,epsion) && GreaterEqualthan(l0,l2,epsion)) || ( GreaterEqualthan(l1,l2,epsion) && GreaterEqualthan(l2,l0,epsion)))
   {
           return tr.next(e);
   }
   else
   {
           return tr.prev(e);
   }
}

inline bool is_frontier_edge_d(Triangulation &tr, bit_vector_d *max_edges, const int e) {
    int twin = tr.twin(e);
    bool is_border_edge = tr.is_border_face(e) || tr.is_border_face(twin);
    bool is_not_max_edge = !(max_edges[e] || max_edges[twin]);
    if(is_border_edge || is_not_max_edge)
        return 1;
    else
        return 0;
}

void label_phase(Triangulation &tr, bit_vector_d *max_edges, bit_vector_d *frontier_edges, int n){
    std::cout << "[DEBUG] kernel_omp.h: label_phase(n = " << n << ") llamado." << std::endl;
    #pragma omp parallel for
    for (int off = 0; off < n; off++){
        frontier_edges[off] = 0;
        if(is_frontier_edge_d(tr, max_edges, off))
            frontier_edges[off] = 1;
    }
}

void label_edges_max_d(Triangulation &tr, bit_vector_d *output, int n_faces) {
    std::cout << "[DEBUG] kernel_omp.h: label_edges_max_d(n_faces = " << n_faces << ") llamado." << std::endl;
    #pragma omp parallel for
    for(int off = 0; off < n_faces; off++) {
        // tr.incident_halfedge(off) es 3*off
        int edge_max_index = compute_max_edge_d(tr, tr.incident_halfedge(off));
        
        
        output[edge_max_index] = 1;
    }
}

inline bool is_seed_edge_d(Triangulation &tr, bit_vector_d *max_edges, int e){
    int twin = tr.twin(e);

    bool is_terminal_edge = (tr.is_interior_face(twin) &&  (max_edges[e] && max_edges[twin]) );
    bool is_terminal_border_edge = (tr.is_border_face(twin) && max_edges[e]);

    if( (is_terminal_edge && e < twin ) || is_terminal_border_edge){
        return true;
    }

    return false;
}

void seed_phase_d(Triangulation &tr, bit_vector_d *max_edges, int *seed_edges, int n_halfedges){
    std::cout << "[DEBUG] kernel_omp.h: seed_phase_d(n = " << n_halfedges << ") llamado." << std::endl;
    #pragma omp parallel for
    for (int off = 0; off < n_halfedges; off++){
        if(tr.is_interior_face(off) && is_seed_edge_d(tr, max_edges, off))
            seed_edges[off] = 1;
    }
}


// -------------------------------------------------------------------
// INICIO: Funciones de Scan/Compaction (basadas en tu código)
// -------------------------------------------------------------------

/**
 * @brief (GPolylla: Fase 8 y 9 combinadas)
 * Compactación serial (un solo hilo) de un bit-vector.
 * Basado en la función 'compaction_parallel' (corregida) que proporcionaste.
 * Realiza un "scan directo" (recorrido único) para compactar los índices.
 *
 * @param output_vec Vector de salida (output_seeds)
 * @param auxiliary El "bit-vector" de entrada (h_seed_edges)
 * @param size El número total de halfedges (n_halfedges)
 * @return El número total de seeds encontrados (m_polygons / h_num)
 */
template <typename V>
int compaction_direct_serial(std::vector<int> &output_vec, // output
                               V *auxiliary,                 // auxiliary (bit-vector)
                               int size)                     // size
{
    std::cout << "[DEBUG] kernel_omp.h: Usando compaction_direct_serial(n = " << size << ")..." << std::endl;
    
    output_vec.clear(); // Limpiamos el vector de salida por si acaso

    // Esta es la lógica serial (y correcta) de la función que proporcionaste.
    // La versión paralela tiene una condición de carrera y no funciona.
     int j=0;
    for (int i = 0; i < size; i++)
    {
        // if (auxiliary[i] == 1)
        if (static_cast<int>(auxiliary[i]) == 1) // V es float
        {
            // En GPolylla, guardamos el ÍNDICE 'i'
            // output[j] = input[i]; (donde input[i] es solo el índice 'i')
            output_vec.push_back(i); 
            j++;
        }
    }
    return j; // *h_num = j;
}

// -------------------------------------------------------------------
// FIN: Funciones de Scan/Compaction
// -------------------------------------------------------------------


inline int search_next_frontier_edge_d(Triangulation &tr, bit_vector_d *frontier_edges, const int e) {
    int nxt = e;
    while(!frontier_edges[nxt])
    {
        nxt = tr.CW_edge_to_vertex(nxt);
    }  
    return nxt;
}

inline int search_prev_frontier_edge_d(Triangulation &tr, bit_vector_d *frontier_edges, const int e) {
    int prv = e;
    while(!frontier_edges[prv])
    {
        prv = tr.CCW_edge_to_vertex(prv);
    }  
    return prv;
}

void travel_phase_d(Triangulation &tr, Triangulation &output_tr, bit_vector_d *max_edges, bit_vector_d *frontier_edges, int n_halfedges){
    std::cout << "[DEBUG] kernel_omp.h: travel_phase_d(n = " << n_halfedges << ") llamado." << std::endl;
    
    // Copiamos los halfedges de 'tr' (entrada) a 'output_tr' (salida)
    output_tr.HalfEdges = tr.HalfEdges;
    
    #pragma omp parallel for
    for (int off = 0; off < n_halfedges; off++){
        // Modificamos los punteros next/prev en la *copia de salida*
        output_tr.HalfEdges[off].next = search_next_frontier_edge_d(tr, frontier_edges, tr.next(off));
        output_tr.HalfEdges[off].prev = search_prev_frontier_edge_d(tr, frontier_edges, tr.prev(off));
    }
}


inline int calculate_middle_edge_d(Triangulation &tr, bit_vector_d *frontier_edges, const int v){
    int frontieredge_with_bet = search_next_frontier_edge_d(tr, frontier_edges, tr.edge_of_vertex(v));
    int internal_edges = tr.degree(v) - 1; //internal-edges incident to v
    int adv = (internal_edges%2 == 0) ? internal_edges/2 - 1 : internal_edges/2 ;
    int nxt = tr.CW_edge_to_vertex(frontieredge_with_bet);
    //back to traversing the edges of v_bet until select the middle-edge
    while (adv != 0){
        nxt = tr.CW_edge_to_vertex(nxt);
        adv--;
    }
    return nxt;
}

//Return the number of frontier edges of a vertex
inline int count_frontier_edges_d(Triangulation &tr, bit_vector_d *frontier_edges, int v){
    
    // CORRECCIÓN DE BUG: El bucle debe comparar con la arista inicial, no
    // llamar a edge_of_vertex(v) en cada iteración.
    
    int e_start = tr.edge_of_vertex(v);
    if (e_start == -1) return 0; // Vértice aislado

    int e = e_start;
    int count = 0;
    do{
        if(frontier_edges[e] == 1)
            count++;
        e = tr.CW_edge_to_vertex(e);
    } while(e != e_start); // <--- Bucle corregido
    
    return count;
}

// new repair phase
void label_extra_frontier_edge_d(Triangulation &tr, bit_vector_d *frontier_edges, int *seed_edges, int n_vertices){
    std::cout << "[DEBUG] kernel_omp.h: label_extra_frontier_edge_d(n_vertices = " << n_vertices << ") llamado." << std::endl;
    #pragma omp parallel for
    for (int v = 0; v < n_vertices; v++){

        if(count_frontier_edges_d(tr, frontier_edges, v) == 1){
            int middle_edge = calculate_middle_edge_d(tr, frontier_edges, v);

            int t1 = middle_edge;
            int t2 = tr.twin(middle_edge);

            //edges of middle-edge are labeled as frontier-edge
             
            frontier_edges[t1] = 1;
             
            frontier_edges[t2] = 1;

             
            seed_edges[t1] = 1;
            seed_edges[t2] = 1;
        }
    }  
}

void search_frontier_edge_d(Triangulation &tr, bit_vector_d *frontier_edges,  int *seed_edges, int n_halfedges) {
    std::cout << "[DEBUG] kernel_omp.h: search_frontier_edge_d(n = " << n_halfedges << ") llamado." << std::endl;
    #pragma omp parallel for
    for (int off = 0; off < n_halfedges; off++){
        if(seed_edges[off] == 1){
            int nxt = off;
            while(!frontier_edges[nxt])
            {
                nxt = tr.CW_edge_to_vertex(nxt);
            }  
            if(nxt != off)
                seed_edges[off] = 0;
            
             
            seed_edges[nxt] = 1;
        }
    }
}

void overwrite_seed_d(Triangulation &tr, int *seed_edges, int n_halfedges){
    std::cout << "[DEBUG] kernel_omp.h: overwrite_seed_d(n = " << n_halfedges << ") llamado." << std::endl;
    #pragma omp parallel for
    for (int i = 0; i < n_halfedges; i++){        
        if(seed_edges[i] == 1){
            int e_init = i;
            int min_ind = e_init;
            int e_curr = tr.next(e_init);
            while(e_init != e_curr){
                min_ind = std::min(min_ind, e_curr);
                e_curr = tr.next(e_curr);
            }
            
            if(min_ind != i){
                seed_edges[i] = 0;
            }
            
             
            seed_edges[min_ind] = 1;
        }
    }  
}