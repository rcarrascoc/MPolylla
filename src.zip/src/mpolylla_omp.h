#pragma once

#include "kernel_omp.h" 
#include <omp.h>
#include <chrono>
#include <iostream>
#include <cstring>      // Para memcpy y memset
#include <vector>       // Para std::vector
#include <fstream>      // Para std::ofstream
#include <iomanip>      // Para std::setprecision
#include <string>       // Para std::string
#include <atomic>       // Para std::atomic

// NOTA: Las funciones de scan/compaction ahora están en kernel_omp.h

// Temporizador de CPU usando std::chrono
struct CPUTimer {
    std::chrono::high_resolution_clock::time_point start;
    std::chrono::high_resolution_clock::time_point stop;

    CPUTimer() {}
    ~CPUTimer() {}

    void Start() {
        start = std::chrono::high_resolution_clock::now();
    }

    void Stop() {
        stop = std::chrono::high_resolution_clock::now();
    }

    float Elapsed() {
        return std::chrono::duration<float, std::milli>(stop - start).count();
    }
};


/*
Esta clase contiene la estructura principal del algoritmo MPolylla
(Nombres de variables alineados con GPolylla original)
*/
class MPolylla{
    private:
        // Punteros a los datos de la triangulación (como en GPolylla)
        Triangulation *mesh_input;
        Triangulation *mesh_output;

        // Búferes de trabajo internos de MPolylla
        // (Equivalentes a max_edges_d, frontier_edges_d, seed_edges_ad en GPolylla)
        bit_vector_d *h_max_edges;
        bit_vector_d *h_frontier_edges;
        int *h_seed_edges;    // bit-vector (1.0f / 0.0f) -> GPolylla::seed_edges_ad
        
        // (h_scan y h_seed_edges_comp ya no son necesarios como miembros de la clase)
        
        int *h_comp_sec_output_seed; // (Buffer de main.cpp)

        // Miembros de GPolylla necesarios para print_OFF
        int m_polygons = 0; // GPolylla::seed_len
        std::vector<int> output_seeds; // GPolylla::output_seeds

        // número de items
        int n_vertices;
        int n_halfedges;
        int n_faces;
        
        // temporizador
        CPUTimer timer;

    public:
        // Constructor
        MPolylla(Triangulation &input, Triangulation &output) {
            mesh_input = &input;
            mesh_output = &output;
            
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor MPolylla(input, output) llamado." << std::endl;
            
            // set number of items
            n_vertices = mesh_input->n_vertices;
            n_halfedges = mesh_input->n_halfedges;
            n_faces = mesh_input->n_faces;
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: n_vertices=" << n_vertices << ", n_halfedges=" << n_halfedges << ", n_faces=" << n_faces << std::endl;

            // alocar memoria de host (solo búferes de trabajo)
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Alocando h_max_edges[" << n_halfedges << "]" << std::endl;
            h_max_edges = new bit_vector_d[n_halfedges];
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Alocando h_frontier_edges[" << n_halfedges << "]" << std::endl;
            h_frontier_edges = new bit_vector_d[n_halfedges];
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Alocando h_seed_edges (bit-vector)[" << n_halfedges << "]" << std::endl;
            h_seed_edges = new int[n_halfedges]; 
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Alocando h_comp_sec_output_seed[" << n_halfedges << "]" << std::endl;
            h_comp_sec_output_seed = new int[n_halfedges];
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Memoria de trabajo alocada." << std::endl;
            
            // inicializar memoria a 0
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor: Inicializando memoria (memset)..." << std::endl;
            memset(h_max_edges, 0, sizeof(bit_vector_d)*n_halfedges);
            memset(h_frontier_edges, 0, sizeof(bit_vector_d)*n_halfedges);
            memset(h_seed_edges, 0, sizeof(int)*n_halfedges); 
            std::cout << "[DEBUG] mpolylla_omp.h: Constructor MPolylla: Fin." << std::endl;
        }

        // liberar memoria
        ~MPolylla(){
            std::cout << "[DEBUG] mpolylla_omp.h: Destructor ~MPolylla() llamado." << std::endl;
            // Solo liberamos la memoria que alocamos
            delete[] h_max_edges;
            delete[] h_frontier_edges;
            delete[] h_seed_edges; 
            // h_scan y h_seed_edges_comp ya no existen
            delete[] h_comp_sec_output_seed;
            std::cout << "[DEBUG] mpolylla_omp.h: Destructor ~MPolylla: Fin." << std::endl;
        }

        // Esta función ahora sigue el orden de GPolylla::construct_Polylla
        void run(){
            std::cout << "[DEBUG] mpolylla_omp.h: run() [construct_Polylla] llamado." << std::endl;
            
            // --- Fases 1, 2, 3 (Label, Frontier, Seed) ---
            // (GPolylla: Label max edges, Label frontier edges, Label seed edges 1)
            std::cout << "[DEBUG] mpolylla_omp.h: run: Iniciando Fases 1-3: Label, Frontier, Seed..." << std::endl;
            timer.Start();
            label_edges_max_d(*mesh_input, h_max_edges, n_faces);
            label_phase(*mesh_input, h_max_edges, h_frontier_edges, n_halfedges);
            seed_phase_d(*mesh_input, h_max_edges, h_seed_edges, n_halfedges);
            timer.Stop();
            printf ("[TIME] Label/Frontier/Seed phases (GPolylla 1, 2, 3): %f\n", (float) timer.Elapsed());

            // --- Fase 4 (Repair) ---
            // (GPolylla: Repair phase)
            std::cout << "[DEBUG] mpolylla_omp.h: run: Iniciando Fase 4: Repair (label_extra_frontier_edge_d)..." << std::endl;
            timer.Start();
            label_extra_frontier_edge_d(*mesh_input, h_frontier_edges, h_seed_edges, n_vertices);
            timer.Stop();
            printf ("[TIME] Repair phase (GPolylla 4): %f\n", (float) timer.Elapsed());

            // --- Fase 5 (Travel) ---
            // (GPolylla: Travel)
            std::cout << "[DEBUG] mpolylla_omp.h: run: Iniciando Fase 5: Travel..." << std::endl;
            timer.Start();
            travel_phase_d(*mesh_input, *mesh_output, h_max_edges, h_frontier_edges, n_halfedges);
            timer.Stop();
            printf ("[TIME] Travel phase (GPolylla 5): %f\n", (float) timer.Elapsed());

            // --- Fase 6 (Post-Travel Repair) ---
            // (GPolylla: Repair search frontier edge, Repair overwrite seed)
            std::cout << "[DEBUG] mpolylla_omp.h: run: Iniciando Fase 6: Post-Travel Repair..." << std::endl;
            timer.Start();
            // Estas funciones modifican h_seed_edges ANTES del scan final
            search_frontier_edge_d(*mesh_output, h_frontier_edges, h_seed_edges, n_halfedges);
            overwrite_seed_d(*mesh_output, h_seed_edges, n_halfedges);
            timer.Stop();
            printf ("[TIME] Post-Travel Repair phase (GPolylla 6, 7): %f\n", (float) timer.Elapsed());


            // ---------------------------------------------------
            // INICIO DE SECCIÓN MODIFICADA (FASE 7)
            // ---------------------------------------------------

            // --- Fase 7 (Compaction Directa) ---
            // (GPolylla: Fases 8 y 9 combinadas)
            // (Petición de usuario: "scan directo" (compactación serial sin scan previo))
            std::cout << "[DEBUG] mpolylla_omp.h: run: Iniciando Fase 7: Compaction (Directa)..." << std::endl;
            timer.Start();
            
            // 7.1. Bucle de compactación serial (reemplaza scan + compaction)
            std::cout << "[DEBUG] mpolylla_omp.h: run: 7.1. Ejecutando Compaction (compaction_direct_serial)..." << std::endl;
            
            // Llama a la nueva función de kernel_omp.h
            // h_seed_edges es el bit-vector ('auxiliary').
            // output_seeds es el vector de salida ('output').
            // m_polygons recibe el conteo total (el 'j' devuelto).
            m_polygons = compaction_direct_serial(output_seeds, h_seed_edges, n_halfedges);
            
            std::cout << "[DEBUG] mpolylla_omp.h: run: 7.2. " << m_polygons << " polígonos (seeds) contados." << std::endl;

            timer.Stop();
            printf ("[TIME] Compaction phase (GPolylla 8, 9): %f\n", (float) timer.Elapsed());

            // ---------------------------------------------------
            // FIN DE SECCIÓN MODIFICADA
            // ---------------------------------------------------

            // --- Fase 8: Copia Final ---
            
            // Copiar vértices (no cambiaron)
            mesh_output->Vertices = mesh_input->Vertices;
            
            // Copiar datos de compactación (para los punteros de 'output' que definió main)
            // (h_scan ya no existe, por lo que get_seed_edges se simplifica)
            std::cout << "[DEBUG] mpolylla_omp.h: run: Copiando datos (opcional)..." << std::endl;
            if (mesh_output->seed_edges != nullptr)
                get_seed_edges(mesh_output->seed_edges, nullptr, h_comp_sec_output_seed);
            if (mesh_output->comp_sec_output_seed != nullptr)
                memcpy(mesh_output->comp_sec_output_seed, h_comp_sec_output_seed, sizeof(int)*n_halfedges);

            // output_seeds ya fue llenado en la Fase 7.
            
            std::cout << "[DEBUG] mpolylla_omp.h: run: Fin." << std::endl;
        }

        // Función auxiliar para 'main.cpp' (si la necesita)
        // (Modificada para no requerir 'h_scan')
        void get_seed_edges(int *seed_edges, int *scan, int *comp_sec_output_seed){
            std::cout << "[DEBUG] mpolylla_omp.h: get_seed_edges(...) llamado." << std::endl;
            // Castea los floats (1.0f) a ints (1)
            #pragma omp parallel for
            for(int i = 0; i < n_halfedges; i++) {
                seed_edges[i] = static_cast<int>(h_seed_edges[i]);
            }
            
            // 'scan' (h_scan) ya no se usa, así que omitimos el memcpy
            // if (scan != nullptr)
            //     memcpy(scan, h_scan, sizeof(int)*n_halfedges);
            
            memcpy(comp_sec_output_seed, h_comp_sec_output_seed, sizeof(int)*n_halfedges);
            std::cout << "[DEBUG] mpolylla_omp.h: get_seed_edges: Fin." << std::endl;
        }

        // Función auxiliar para 'main.cpp' (si la necesita)
        void get_frontier_edges(int *frontier_edges){
            std::cout << "[DEBUG] mpolylla_omp.h: get_frontier_edges(...) llamado." << std::endl;
            memcpy(frontier_edges, h_frontier_edges, sizeof(int)*n_halfedges);
            std::cout << "[DEBUG] mpolylla_omp.h: get_frontier_edges: Fin." << std::endl;
        }

    // Función print_OFF (original de GPolylla)
    void print_OFF(std::string filename){
        std::ofstream out(filename);

        std::cout << "Printing OFF file" <<  mesh_output->vertices() << " " << m_polygons << std::endl;

      //  out<<"{ appearance  {+edge +face linewidth 2} LIST\n";
        out<<"OFF"<<std::endl;
        //num_vertices num_polygons 0
        out<<std::setprecision(15)<<mesh_output->vertices()<<" "<<m_polygons<<" 0"<<std::endl;
        //print nodes
        for(std::size_t v = 0; v < mesh_output->vertices(); v++)
            out<<mesh_output->get_PointX(v)<<" "<<mesh_output->get_PointY(v)<<" 0"<<std::endl;
        //print polygons
        //printf("-------> 1\n");
        int size_poly;
        int e_curr;
        //std::cout<<"aca"<<std::endl;
        for(auto &e_init : output_seeds){
            size_poly = 1;
            e_curr = mesh_output->next(e_init);
            //std::cout<<"poly"<<"e_init"<<e_init<<std::endl;
            while(e_init != e_curr){
              //  std::cout<<"e_init "<<e_init<<" e_curr "<<e_curr<<std::endl;
                size_poly++;
                e_curr = mesh_output->next(e_curr);
            }
            out<<size_poly<<" ";            
            
            out<<mesh_output->origin(e_init)<<" ";
            e_curr = mesh_output->next(e_init);
            while(e_init != e_curr){
                out<<mesh_output->origin(e_curr)<<" ";
                e_curr = mesh_output->next(e_curr);
            }
            out<<std::endl; 
            //count++;
            //printf("-------> 1.1 %d\n", count);
        }
        //printf("-------> 2\n");
      //  out<<"}"<<std::endl;
        out.close();
    }
};