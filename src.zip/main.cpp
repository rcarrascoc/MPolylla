#include <stdio.h>
#include <string>
#include <iostream> // <--- Añadido para std::cout
#include "src/triangulation.h"  // Tu nueva clase Triangulation
#include "src/mpolylla_omp.h"   // La clase MPolylla convertida

int main(int argc, char* argv[])
{
    std::cout << "[DEBUG] main: Inicio de main." << std::endl;

    if (argc < 2){
        printf("Error: Archivo de entrada no especificado.\n");
        printf("Uso: ./MPolylla_OMP <archivo_entrada.off> [archivo_salida.off]\n");
        return 0;
    }

    std::string input_file_name(argv[1]);
    std::string output_file_name("output.off");
    
    if (argc > 2)
        output_file_name = std::string(argv[2]);

    bool verbose = false; // Puedes cambiar esto o añadir un flag
    
    std::cout << "[DEBUG] main: Argumentos procesados." << std::endl;
    std::cout << "[DEBUG] main: Archivo de entrada: " << input_file_name << std::endl;
    std::cout << "[DEBUG] main: Archivo de salida: " << output_file_name << std::endl;

    
    printf("Leyendo archivo .off y construyendo triangulación...\n");
    std::cout << "[DEBUG] main: Llamando constructor Triangulation(input_file_name)..." << std::endl;
    
    // 1. triangulation.h maneja la lectura del .off en su constructor
    // CORRECCIÓN: 'triangulation' es ahora 'Triangulation' (nombre de la clase)
    Triangulation input(input_file_name);
    
    std::cout << "[DEBUG] main: Constructor Triangulation finalizado." << std::endl;
    std::cout << "[DEBUG] main: n_vertices=" << input.n_vertices << ", n_faces=" << input.n_faces << ", n_halfedges=" << input.n_halfedges << std::endl;

    if (verbose) {
        printf("------ Triangulación de Entrada (desde .off) ------\n");
        // print_triangulation(input); // Puedes añadir esta función a triangulation.h si la necesitas
        // check_triangulation(input); // Puedes añadir esta función a triangulation.h si la necesitas
    }

    // 2. Preparar la estructura de salida
    std::cout << "[DEBUG] main: Preparando estructura output..." << std::endl;
    // CORRECCIÓN: 'triangulation' es ahora 'Triangulation' (nombre de la clase)
    Triangulation output;
    output.Vertices.resize(input.n_vertices);
    output.HalfEdges.resize(input.n_halfedges);
    
    // Asignar memoria para los punteros de datos de compactación (opcional)
    // Comprobar si n_halfedges es válido antes de alocar
    if (input.n_halfedges <= 0) {
        std::cerr << "[ERROR] main: n_halfedges es 0 o negativo. No se puede alocar memoria." << std::endl;
        return 1;
    }

    output.n_vertices = input.n_vertices;
    output.n_faces = input.n_faces;
    output.n_halfedges = input.n_halfedges;

    std::cout << "[DEBUG] main: Alocando output.seed_edges[" << input.n_halfedges << "]..." << std::endl;
    output.seed_edges = new int[input.n_halfedges];
    std::cout << "[DEBUG] main: Alocando output.comp_sec_output_seed[" << input.n_halfedges << "]..." << std::endl;
    output.comp_sec_output_seed = new int[input.n_halfedges];
    std::cout << "[DEBUG] main: Estructura output preparada." << std::endl;


    printf("Ejecutando MPolylla (OpenMP)...\n");
    
    // 3. Crear y ejecutar MPolylla
    std::cout << "[DEBUG] main: Llamando constructor MPolylla(input, output)..." << std::endl;
    MPolylla mpolylla(input, output); // Pasa la triangulación de entrada y salida
    std::cout << "[DEBUG] main: Constructor MPolylla finalizado." << std::endl;
    
    std::cout << "[DEBUG] main: Llamando mpolylla.run()..." << std::endl;
    mpolylla.run();     // Ejecuta el algoritmo que llenará la estructura de salida
    std::cout << "[DEBUG] main: mpolylla.run finalizado." << std::endl;
    
    printf("Ejecución de MPolylla finalizada.\n");

    if (verbose) {
        printf("------ Triangulación de Salida (Polígonos) ------\n");
        // print_triangulation(output); 
    }

    // 4. Escribir el resultado a un nuevo archivo .off
    printf("Escribiendo archivo de salida...\n");
    std::cout << "[DEBUG] main: Llamando print_OFF(...)..." << std::endl;
    mpolylla.print_OFF(output_file_name);
    std::cout << "[DEBUG] main: print_OFF finalizado." << std::endl;
    printf("Archivo de salida escrito en: %s\n", output_file_name.c_str());

    // 5. Liberar memoria
    std::cout << "[DEBUG] main: Liberando memoria de punteros de salida..." << std::endl;
    delete[] output.seed_edges;
    delete[] output.comp_sec_output_seed;
    std::cout << "[DEBUG] main: Memoria liberada." << std::endl;
    
    std::cout << "[DEBUG] main: Fin de main." << std::endl;
    return 0;
}